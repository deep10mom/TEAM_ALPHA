/**
 * 
 */
package com.bankapplication.bankserver.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankapplication.bankserver.model.Registration;
import com.bankapplication.bankserver.model.Registration;

/**
 * @author Abridge
 *
 */
public interface RegistrationRepo extends JpaRepository<Registration, Integer> {
	
	public Registration save(Registration registration);
	public Optional<Registration> findById(int id);
	public List<Registration> findAll();
	public void deleteById(Integer id);
	public boolean existsById(Integer id);

}
