package com.bankapplication.bankserver.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bankapplication.bankserver.dao.AccountsRepo;
import com.bankapplication.bankserver.dao.BranchRepo;
import com.bankapplication.bankserver.dao.RegistrationRepo;
import com.bankapplication.bankserver.dao.TransactionHistoryRepo;
import com.bankapplication.bankserver.model.Accounts;
import com.bankapplication.bankserver.model.Branch;
import com.bankapplication.bankserver.model.Registration;
import com.bankapplication.bankserver.model.TransactionHistory;




@RestController
@RequestMapping("/bankapp")
@CrossOrigin(origins = "http://localhost:4200")
public class WebController {

	
//	Branch Controller Code
	
	@Autowired
	BranchRepo repo;
	
	
	@GetMapping("/test")
	public String test()
	{
		return "Hello world";
	}
	@PostMapping("/branches")
	public Branch createBranch(@RequestBody Branch branch)
	{
		return repo.save(branch);
	}
	
	@GetMapping("/branches/{id}")
	public Optional<Branch> findById(@PathVariable Integer id)
	{
		return repo.findById(id);
	}
	@GetMapping("/branches")
	public List<Branch> findAll()
	{
		return repo.findAll();
		
	}
	@PutMapping("/branches")
	public Branch updateBranch(@RequestBody Branch branch)
	{ 
		boolean k;
		k=repo.existsById(branch.getId());
		if(k==true)
		{
			return repo.save(branch);
		}
		return null;
		
		
	}
	
	
//	Accounts Controller Code
	
	
	@Autowired
	AccountsRepo repo1;
	
	@PostMapping("/accounts")
	public Accounts createAccount(@RequestBody Accounts account)
	{
		return repo1.save(account);
	}
	
	@GetMapping("/accounts/{id}")
	public Optional<Accounts> findByIdAccount(@PathVariable Integer id)
	{
		return repo1.findById(id);
	}
	@GetMapping("/accounts")
	public List<Accounts> findAllAccounts()
	{
		return repo1.findAll();
		
	}
	@PutMapping("/accounts")
	public Accounts updateAccounts(@RequestBody Accounts account)
	{ 
		boolean k;
		k=repo1.existsById(account.getId());
		if(k==true)
		{
			return repo1.save(account);
		}
		return null;
		
		
	}
	
	
//	Registration Controller Code


	@Autowired
	RegistrationRepo repo2;
	
	@PostMapping("/registration")
	public Registration createRegistration(@RequestBody Registration registration)
	{
		return repo2.save(registration);
	}
	
	@GetMapping("/registration/{id}")
	public Optional<Registration> findByIdRegister(@PathVariable Integer id)
	{
		return repo2.findById(id);
	}
	@GetMapping("/registration")
	public List<Registration> findAllRegister()
	{
		return repo2.findAll();
		
	}
	@PutMapping("/registration")
	public Registration updateRegister(@RequestBody Registration register)
	{ 
		boolean k;
		k=repo2.existsById(register.getId());
		if(k==true)
		{
			return repo2.save(register);
		}
		return null;
		
		
	}
	
	
//	Transaction History Controller Code
	
	

	@Autowired
	TransactionHistoryRepo repo3;
	
	@PostMapping("/transaction")
	public TransactionHistory create(@RequestBody TransactionHistory transaction)
	{
		return repo3.save(transaction);
	}
	
	@GetMapping("/transaction/{id}")
	public Optional<TransactionHistory> findByIdTransaction(@PathVariable Integer id)
	{
		return repo3.findById(id);
	}
	@GetMapping("/transaction")
	public List<TransactionHistory> findAllTransaction()
	{
		return repo3.findAll();
		
	}
	@PutMapping("/transaction")
	public TransactionHistory updateTransaction(@RequestBody TransactionHistory transaction)
	{ 
		boolean k;
		k=repo1.existsById(transaction.getId());
		if(k==true)
		{
			return repo3.save(transaction);
		}
		return null;
		
		
	}
	
	public WebController() {
		// TODO Auto-generated constructor stub
	}

}
