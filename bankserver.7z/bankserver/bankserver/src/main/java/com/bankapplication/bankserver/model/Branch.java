package com.bankapplication.bankserver.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Entity
public class Branch {
	@Id
	
	int id;
	String brachname;
	String  ifsccode;
	
	public Branch(int id, String brachname, String ifsccode) {
		super();
		this.id = id;
		this.brachname = brachname;
		this.ifsccode = ifsccode;
	}

	@Override
	public String toString() {
		return "Branch [id=" + id + ", brachname=" + brachname + ", ifsccode=" + ifsccode + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brachname == null) ? 0 : brachname.hashCode());
		result = prime * result + id;
		result = prime * result + ((ifsccode == null) ? 0 : ifsccode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Branch other = (Branch) obj;
		if (brachname == null) {
			if (other.brachname != null)
				return false;
		} else if (!brachname.equals(other.brachname))
			return false;
		if (id != other.id)
			return false;
		if (ifsccode == null) {
			if (other.ifsccode != null)
				return false;
		} else if (!ifsccode.equals(other.ifsccode))
			return false;
		return true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrachname() {
		return brachname;
	}

	public void setBrachname(String brachname) {
		this.brachname = brachname;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public Branch() {
		// TODO Auto-generated constructor stub
	}

}
