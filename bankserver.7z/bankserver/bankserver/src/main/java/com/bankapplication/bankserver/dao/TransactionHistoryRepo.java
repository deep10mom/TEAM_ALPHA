/**
 * 
 */
package com.bankapplication.bankserver.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankapplication.bankserver.model.TransactionHistory;

/**
 * @author Abridge
 *
 */
public interface TransactionHistoryRepo extends JpaRepository<TransactionHistory, Integer> {
	
	public TransactionHistory save(TransactionHistory transactionHistory);
	public Optional<TransactionHistory> findById(int id);
	public List<TransactionHistory> findAll();
	public void deleteById(Integer id);
	public boolean existsById(Integer id);

}
