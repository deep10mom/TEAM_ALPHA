package com.bankapplication.bankserver.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Accounts {

	@Id
	
	int id;
	int userid;
	int accountnumber;
	String acctype;
	int balance;
	Date dateofcreation;
	Date dateofdeletion;
	int branchid;
	
	
	
	 public Accounts() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Accounts(int id, int userid, int accountnumber, String acctype, int balance, Date dateofcreation,
			Date dateofdeletion, int branchid) {
		super();
		this.id = id;
		this.userid = userid;
		this.accountnumber = accountnumber;
		this.acctype = acctype;
		this.balance = balance;
		this.dateofcreation = dateofcreation;
		this.dateofdeletion = dateofdeletion;
		this.branchid = branchid;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountnumber;
		result = prime * result + ((acctype == null) ? 0 : acctype.hashCode());
		result = prime * result + balance;
		result = prime * result + branchid;
		result = prime * result + ((dateofcreation == null) ? 0 : dateofcreation.hashCode());
		result = prime * result + ((dateofdeletion == null) ? 0 : dateofdeletion.hashCode());
		result = prime * result + id;
		result = prime * result + userid;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Accounts other = (Accounts) obj;
		if (accountnumber != other.accountnumber)
			return false;
		if (acctype == null) {
			if (other.acctype != null)
				return false;
		} else if (!acctype.equals(other.acctype))
			return false;
		if (balance != other.balance)
			return false;
		if (branchid != other.branchid)
			return false;
		if (dateofcreation == null) {
			if (other.dateofcreation != null)
				return false;
		} else if (!dateofcreation.equals(other.dateofcreation))
			return false;
		if (dateofdeletion == null) {
			if (other.dateofdeletion != null)
				return false;
		} else if (!dateofdeletion.equals(other.dateofdeletion))
			return false;
		if (id != other.id)
			return false;
		if (userid != other.userid)
			return false;
		return true;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getUserid() {
		return userid;
	}



	public void setUserid(int userid) {
		this.userid = userid;
	}



	public int getAccountnumber() {
		return accountnumber;
	}



	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}



	public String getAcctype() {
		return acctype;
	}



	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}



	public int getBalance() {
		return balance;
	}



	public void setBalance(int balance) {
		this.balance = balance;
	}



	public Date getDateofcreation() {
		return dateofcreation;
	}



	public void setDateofcreation(Date dateofcreation) {
		this.dateofcreation = dateofcreation;
	}



	public Date getDateofdeletion() {
		return dateofdeletion;
	}



	public void setDateofdeletion(Date dateofdeletion) {
		this.dateofdeletion = dateofdeletion;
	}



	public int getBranchid() {
		return branchid;
	}



	public void setBranchid(int branchid) {
		this.branchid = branchid;
	}



}
