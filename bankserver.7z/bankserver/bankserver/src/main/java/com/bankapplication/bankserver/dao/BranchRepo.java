package com.bankapplication.bankserver.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankapplication.bankserver.model.Branch;


public interface BranchRepo extends JpaRepository<Branch,Integer> {
	public Branch save(Branch branch);
	public Optional<Branch> findById(int id);
	public List<Branch> findAll();
	public void deleteById(Integer id);
	public boolean existsById(Integer id);

}
