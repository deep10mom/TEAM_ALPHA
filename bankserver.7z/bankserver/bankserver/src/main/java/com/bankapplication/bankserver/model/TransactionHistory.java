/**
 * 
 */
package com.bankapplication.bankserver.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * @author Abridge
 *
 */

//{"id":1,"myAccountNumber":14678,"accountNumber":12345,"amount":2500,"status":"true","date":"2019-04-05"}
@Entity
public class TransactionHistory {

	/**
	 * 
	 */
	@Id
	
	int id;
	int myAccountNumber;
	int accountNumber;
	int amount;
	boolean status;
	Date date;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMyAccountNumber() {
		return myAccountNumber;
	}
	public void setMyAccountNumber(int myAccountNumber) {
		this.myAccountNumber = myAccountNumber;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "TransactionHistory [id=" + id + ", myAccountNumber=" + myAccountNumber + ", accountNumber="
				+ accountNumber + ", amount=" + amount + ", status=" + status + ", date=" + date + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		result = prime * result + amount;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + id;
		result = prime * result + myAccountNumber;
		result = prime * result + (status ? 1231 : 1237);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionHistory other = (TransactionHistory) obj;
		if (accountNumber != other.accountNumber)
			return false;
		if (amount != other.amount)
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (id != other.id)
			return false;
		if (myAccountNumber != other.myAccountNumber)
			return false;
		if (status != other.status)
			return false;
		return true;
	}
	public TransactionHistory(int id, int myAccountNumber, int accountNumber, int amount, boolean status, Date date) {
		super();
		this.id = id;
		this.myAccountNumber = myAccountNumber;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.status = status;
		this.date = date;
	}
	public TransactionHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	



	



	
}
