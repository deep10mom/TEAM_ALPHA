/**
 * 
 */
package com.bankapplication.bankserver.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankapplication.bankserver.model.Accounts;
import com.bankapplication.bankserver.model.Branch;

/**
 * @author Abridge
 *
 */
public interface AccountsRepo extends JpaRepository<Accounts, Integer> {
	
	public Accounts save(Accounts account);
	public Optional<Accounts> findById(int id);
	public List<Accounts> findAll();
	public void deleteById(Integer id);
	public boolean existsById(Integer id);
	

}
